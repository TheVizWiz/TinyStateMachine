# TinyStateMachine
Tiny State Machine for embedded work. 
